# gemini_client.py
import google.generativeai as genai


class GeminiClient:
    def __init__(self, api_key: str, model: str = "gemini-2.5-pro"):
        # configure API
        genai.configure(api_key=api_key)
        self.model = model
        self.client = genai.GenerativeModel(model)
        self.chat = None

    def start_chat(self):
        """Start a chat session with history (for conversation mode)."""
        self.chat = self.client.start_chat(history=[])

    def send(self, prompt: str, image_path: str | None = None, prefer_chat: bool = False):
        """Send prompt (and optionally image) to Gemini."""
        try:
            if image_path:
                img = {
                    "mime_type": "image/jpeg",
                    "data": open(image_path, "rb").read()
                }
                response = self.client.generate_content([prompt, img])
            else:
                if prefer_chat and self.chat:
                    response = self.chat.send_message(prompt)
                else:
                    response = self.client.generate_content(prompt)

            return response.text if hasattr(response, "text") else str(response)
        except Exception as e:
            return f"[Gemini Error] {e}"
