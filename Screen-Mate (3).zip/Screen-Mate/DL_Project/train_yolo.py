from ultralytics import YOLO

DATA_YAML = r"C:\Users\prana\Desktop\DL_Project_2\DL_Project\DL_Project\ui_dataset\data.yaml"

print("🚀 Starting YOLOv8n-OBB training (ultra low memory mode)...")

model = YOLO("yolov8n-obb.pt")

model.train(
    data=DATA_YAML,
    epochs=10,
    imgsz=960,       # smaller images → less RAM/VRAM
    batch=8,         # safest for 8GB RAM + 4GB VRAM
    workers=0,
    device=0,
    cache=False,
    amp=True,
    half=True,       # force FP16
    mosaic=0.0,
    mixup=0.0,
    copy_paste=0.0,
    patience=7
)

print("🎉 Training finished! Results are in runs/obb/train/")
