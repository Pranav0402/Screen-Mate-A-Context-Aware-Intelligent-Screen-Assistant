import os
import time
import json
import cv2
import mss
import numpy as np
import psutil
import win32gui
import win32process
import torch
from ultralytics import YOLO
import easyocr

# PyQt types
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QApplication

# GPU & OCR
gpu_available = torch.cuda.is_available()
reader = easyocr.Reader(['en'], gpu=gpu_available)
print("Using GPU for OCR:", gpu_available)

# YOLO model path
MODEL_PATH = "ui_best.pt"
yolo_model = YOLO(MODEL_PATH)
print("✅ YOLO model loaded")

CTX_FILE = "context_buffer.jsonl"
CAPTURE_DIR = "captures"
os.makedirs(CAPTURE_DIR, exist_ok=True)

# runtime globals
running = False
LAST_CAPTURE_PATH = None


def get_active_window():
    """Return title and process name of active window."""
    hwnd = win32gui.GetForegroundWindow()
    try:
        pid = win32process.GetWindowThreadProcessId(hwnd)[1]
        process = psutil.Process(pid)
        return {
            "window_title": win32gui.GetWindowText(hwnd),
            "app_name": process.name()
        }
    except Exception:
        return {"window_title": "Unknown", "app_name": "Unknown"}


def get_last_capture():
    """Return path to the last saved screenshot (or None)."""
    global LAST_CAPTURE_PATH
    return LAST_CAPTURE_PATH


def generate_auto_prompt(record):
    """Turn OCR + YOLO data into a smart natural prompt."""
    texts = [d["text"] for d in record.get("ocr", [])]
    objs = [d["class"] for d in record.get("yolo", [])]

    parts = []
    if texts:
        snippet = " ".join(texts[:10])  # up to 10 OCR strings
        parts.append(f"I see text: '{snippet}'")
    if objs:
        uniq_objs = list(set(objs))
        parts.append(f"I notice UI elements: {', '.join(uniq_objs)}")

    if not parts:
        return "Describe what is happening on my screen."

    return "Based on the screen, " + " and ".join(parts) + ". What am I doing?"


def capture_screen(overlay_instance=None, interval=1.0, min_ocr_conf=0.3):
    """
    Capture loop. If overlay_instance is provided it expects:
      - overlay_instance.hide() / show() to avoid capturing itself
      - overlay_instance.update_preview_signal (pyqtSignal) for preview
      - overlay_instance.set_prompt_signal (pyqtSignal) for auto prompts
    """
    global running, LAST_CAPTURE_PATH
    running = True
    frame_count = 0

    with mss.mss() as sct:
        monitor = sct.monitors[1]  # full screen
        while running:
            # hide overlay before grabbing
            if overlay_instance is not None:
                try:
                    overlay_instance.hide()
                    QApplication.processEvents()
                    time.sleep(0.03)
                except Exception:
                    pass

            # grab screen
            img = np.array(sct.grab(monitor))
            frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

            # show overlay again
            if overlay_instance is not None:
                try:
                    overlay_instance.show()
                    QApplication.processEvents()
                except Exception:
                    pass

            record = {"timestamp": time.time()}

            # OCR
            try:
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                ocr_results = reader.readtext(
                    rgb, detail=1, paragraph=False, min_size=20
                )
            except Exception as e:
                ocr_results = []
                print("⚠️ OCR error:", e)

            ocr_data = []
            for bbox, text, conf in ocr_results:
                if conf < min_ocr_conf:
                    continue
                clean_bbox = [[float(x), float(y)] for (x, y) in bbox]
                ocr_data.append({"text": text, "bbox": clean_bbox, "conf": float(conf)})
                pts = np.array(bbox, dtype=np.int32)
                cv2.polylines(frame, [pts], True, (255, 0, 0), 2)
                cv2.putText(frame, text, (int(bbox[0][0]), int(bbox[0][1]) - 5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

            if ocr_data:
                print("🔤 OCR:", [d["text"] for d in ocr_data])

            # YOLO
            yolo_data = []
            try:
                yolo_results = yolo_model.predict(frame, verbose=False)
                for result in yolo_results:
                    for box in result.boxes:
                        cls_id = int(box.cls[0])
                        conf = float(box.conf[0])
                        xyxy = box.xyxy[0].cpu().numpy().tolist()
                        yolo_data.append({
                            "class": yolo_model.names[cls_id],
                            "conf": conf,
                            "bbox": xyxy
                        })
                        x1, y1, x2, y2 = map(int, xyxy)
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        cv2.putText(frame, f"{yolo_model.names[cls_id]} {conf:.2f}",
                                    (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            except Exception as e:
                print("⚠️ YOLO error:", e)

            record.update({
                "ocr": ocr_data,
                "yolo": yolo_data,
                "metadata": get_active_window()
            })

            # append context
            try:
                with open(CTX_FILE, "a", encoding="utf-8") as f:
                    f.write(json.dumps(record) + "\n")
            except Exception as e:
                print("⚠️ write ctx error:", e)

            # save screenshot
            frame_count += 1
            save_path = os.path.join(CAPTURE_DIR, f"frame_{frame_count}.jpg")
            try:
                cv2.imwrite(save_path, frame)
                LAST_CAPTURE_PATH = save_path
                print(f"💾 Saved {save_path}")
            except Exception as e:
                print("⚠️ save image error:", e)

            # send preview back to overlay
            if overlay_instance is not None and hasattr(overlay_instance, "update_preview_signal"):
                try:
                    rgb_preview = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    h, w, ch = rgb_preview.shape
                    bytes_per_line = ch * w
                    qimg = QImage(rgb_preview.data, w, h, bytes_per_line, QImage.Format_RGB888)
                    pixmap = QPixmap.fromImage(qimg)
                    overlay_instance.update_preview_signal.emit(pixmap)
                except Exception as e:
                    print("⚠️ preview emit error:", e)

            # auto prompt generator
            if overlay_instance is not None and getattr(overlay_instance, "auto_mode", False):
                try:
                    auto_prompt = generate_auto_prompt(record)
                    overlay_instance.set_prompt_signal.emit(auto_prompt)
                except Exception as e:
                    print("⚠️ auto-prompt error:", e)

            time.sleep(interval)


def stop_capture():
    """Stop the screen capture loop."""
    global running
    running = False
    print("⏹ Screen capture stopped")
