import json
import re
import time
import threading

# Global variable storing the latest predicted task
current_task = "Detecting..."

def load_jsonl_data(file_path):
    """Load and parse JSONL data"""
    data = []
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except FileNotFoundError:
        pass
    return data

def extract_features_from_entry(entry):
    # Use similar logic as extract_features_from_jsonl, but for a single entry
    ocr_texts = []
    if 'ocr' in entry and entry['ocr']:
        for ocr_item in entry['ocr']:
            if 'text' in ocr_item and ocr_item['text']:
                text = re.sub(r'[^a-zA-Z0-9\s]', '', ocr_item['text'].lower())
                if text.strip():
                    ocr_texts.append(text.strip())

    yolo_classes = []
    if 'yolo' in entry and entry['yolo']:
        for yolo_item in entry['yolo']:
            if 'class' in yolo_item and yolo_item['class']:
                yolo_classes.append(yolo_item['class'].lower())
            elif 'label' in yolo_item and yolo_item['label']:
                yolo_classes.append(yolo_item['label'].lower())

    window_context = []
    metadata = entry.get('metadata', {})
    if 'window_title' in metadata and metadata['window_title']:
        window_context.extend(re.findall(r'\w+', metadata['window_title'].lower()))
    if 'app_name' in metadata and metadata['app_name']:
        window_context.extend(re.findall(r'\w+', metadata['app_name'].lower()))

    all_features = ocr_texts + yolo_classes + window_context
    window_title = metadata.get('window_title', '').lower()

    # --- TASK LABEL RULES ---
    if any(k in window_title for k in ['youtube','netflix','prime video']) or \
       any(k in " ".join(ocr_texts) for k in ['video','watch','subscribe']):
        return 'watching_videos'
    elif any(k in window_title for k in ['visual studio','code.exe','pycharm']) or \
         any(k in " ".join(ocr_texts) for k in ['python','import','def ','class ','function']):
        return 'coding'
    elif any(k in window_title for k in ['debug','traceback','exception']) or \
         any(k in " ".join(ocr_texts) for k in ['error','stack','bug','failed']):
        return 'debugging'
    elif any(k in window_title for k in ['chrome','firefox','edge']) or \
         any(k in " ".join(ocr_texts) for k in ['search','google','http','www']):
        return 'browsing'
    elif any(k in window_title for k in ['word','docs','notepad']) or \
         any(k in " ".join(ocr_texts) for k in ['document','write','paragraph']):
        return 'writing'
    elif any(k in window_title for k in ['excel','sheets']) or \
         any(k in " ".join(ocr_texts) for k in ['sum','pivot','row','column']):
        return 'data_entry'
    elif any(k in window_title for k in ['zoom','meet','teams']) or \
         any(k in " ".join(ocr_texts) for k in ['meeting','call','conference']):
        return 'meeting'
    elif any(k in window_title for k in ['chatgpt','openai']) or \
         any(k in " ".join(ocr_texts) for k in ['chatgpt','ai','assistant']):
        return 'using_ai_tools'
    else:
        return 'other_activity'

    

def prediction_loop(file_path="context_buffer.jsonl", interval=5):
    """Background loop that updates current_task continuously using the latest line only"""
    global current_task
    last_size = 0
    predictor_running = True

    while predictor_running:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                f.seek(last_size)
                lines = f.readlines()
                if lines:
                    last_line = lines[-1].strip()
                    try:
                        entry = json.loads(last_line)
                        task = extract_features_from_entry(entry)
                        if task:
                            current_task = task
                            print(f"🧩 Predicted task: {current_task}")  # 🔥 Debug log
                    except json.JSONDecodeError:
                        print("⚠ JSON decode error on last line")
                last_size = f.tell()
        except FileNotFoundError:
            current_task = "No Activity"
        except Exception as e:
            current_task = f"Prediction Error: {e}"
            print("❌ Prediction error:", e)

        time.sleep(interval)

def start_task_predictor():
    """Start background thread for task prediction"""
    thread = threading.Thread(target=prediction_loop, daemon=True)
    thread.start()

def stop_task_predictor():
    global predictor_running
    predictor_running = False