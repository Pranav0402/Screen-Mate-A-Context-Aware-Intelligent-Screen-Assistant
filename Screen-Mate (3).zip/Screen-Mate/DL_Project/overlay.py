# overlay.py
import os
import sys
import time
import threading
import traceback

from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QLineEdit, QCheckBox, QFrame
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap

import speech_recognition as sr
import pyttsx3

# import functions / modules from your project
# screen_capture.capture_screen will call overlay.update_preview_signal.emit(pixmap)
# and overlay.set_prompt_signal.emit(auto_prompt)
from screen_capture import capture_screen, stop_capture, get_last_capture
from gemini_client import GeminiClient  # make sure this accepts (api_key, model=...)
# NOTE: gemini_client should implement .send(prompt, image_path=None, prefer_chat=True)

# -----------------------
# Overlay (GUI)
# -----------------------
class Overlay(QWidget):
    # Signals — used by background threads to update UI in the main thread
    set_prompt_signal = pyqtSignal(str)        # set auto prompt (full text)
    append_prompt_signal = pyqtSignal(str)     # append mic chunk to prompt
    update_preview_signal = pyqtSignal(object) # QPixmap preview from capture thread
    response_signal = pyqtSignal(str)          # append model response text to response box
    enable_send_signal = pyqtSignal(bool)      # enable/disable send button

    def __init__(self, gemini_api_key: str | None = None, gemini_model: str = "gemini-2.5-pro"):
        super().__init__()
        self.setWindowTitle("Screen-Mate")
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)

        # Read API key from argument or environment
        self.api_key = gemini_api_key or os.environ.get("GEMINI_API_KEY")
        self.gemini_model = gemini_model
        self.gemini = None  # lazy init

        # UI state
        self.capture_thread = None
        self.mic_active = False
        self.mic_thread = None
        self.last_auto_prompt = None
        self.auto_mode = False  # used by screen_capture.py to decide whether to emit prompts (it checks overlay_instance.auto_mode)
        self.tts_engine = pyttsx3.init()
        self.tts_lock = threading.Lock()

        # Build UI
        self._build_ui()

        # Connect signals to slots (thread-safe)
        self.set_prompt_signal.connect(self.handle_set_prompt)
        self.append_prompt_signal.connect(self.handle_append_prompt)
        self.update_preview_signal.connect(self.handle_update_preview)
        self.response_signal.connect(self.handle_response)
        self.enable_send_signal.connect(self.handle_enable_send)

        # Log system ready
        self.append_response("[System] UI ready. Set GEMINI_API_KEY env var or pass key to Overlay.")

    # ---------------- UI building ----------------
    def _build_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)

        # Status label
        self.status_label = QLabel("Task: Idle")
        self.status_label.setStyleSheet("color: white; font-size: 14px;")
        main_layout.addWidget(self.status_label, alignment=Qt.AlignCenter)

        # Preview label (small screenshot preview)
        self.preview_label = QLabel()
        self.preview_label.setFixedSize(360, 200)
        self.preview_label.setStyleSheet("background-color: #111; border: 1px solid #333;")
        main_layout.addWidget(self.preview_label, alignment=Qt.AlignCenter)

        # Separator line
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #444;")
        main_layout.addWidget(sep)

        # Controls row (Start / Stop / Mic / Voice reply / Auto toggle)
        controls = QHBoxLayout()
        self.start_btn = QPushButton("▶ Start")
        self.start_btn.clicked.connect(self.start_capture)
        controls.addWidget(self.start_btn)

        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.clicked.connect(self.stop_capture)
        controls.addWidget(self.stop_btn)

        self.mic_btn = QPushButton("🎤 Mic (Off)")
        self.mic_btn.clicked.connect(self.toggle_mic)
        controls.addWidget(self.mic_btn)

        self.voice_resp_cb = QCheckBox("Voice reply")
        self.voice_resp_cb.setChecked(True)
        controls.addWidget(self.voice_resp_cb)

        # Auto mode toggle
        self.auto_cb = QCheckBox("Auto Prompt")
        self.auto_cb.stateChanged.connect(self.on_toggle_auto)
        controls.addWidget(self.auto_cb)

        main_layout.addLayout(controls)

        # Prompt input row
        prompt_layout = QHBoxLayout()
        self.prompt_input = QLineEdit()
        self.prompt_input.setPlaceholderText("Type prompt here or use Auto Prompt / mic...")
        prompt_layout.addWidget(self.prompt_input)

        self.send_btn = QPushButton("Send")
        self.send_btn.clicked.connect(self.on_send)
        prompt_layout.addWidget(self.send_btn)
        main_layout.addLayout(prompt_layout)

        # Response chat box
        self.response_box = QTextEdit()
        self.response_box.setReadOnly(True)
        main_layout.addWidget(self.response_box)

        # Exit button
        bottom = QHBoxLayout()
        self.exit_btn = QPushButton("❌ Exit")
        self.exit_btn.clicked.connect(self.quit_app)
        bottom.addWidget(self.exit_btn)
        main_layout.addLayout(bottom)

        # Style
        btn_style = """
            QPushButton {
                background-color: rgba(30,30,30,220);
                color: white;
                border-radius: 6px;
                padding: 6px 8px;
            }
            QPushButton:hover { background-color: rgba(60,60,60,230); }
            QLineEdit, QTextEdit { background-color: #111; color: #ddd; border: 1px solid #333; }
            QCheckBox { color: white; }
            QLabel { color: white; }
            """
        self.setStyleSheet(btn_style)
        self.setLayout(main_layout)

    # ---------------- Capture control ----------------
    def start_capture(self):
        if self.capture_thread and self.capture_thread.is_alive():
            return
        self.status_label.setText("Task: Capturing…")
        # Set current auto_mode attribute (screen_capture will check overlay_instance.auto_mode)
        # Start capture loop in a thread (screen_capture will emit preview and set_prompt_signal)
        self.capture_thread = threading.Thread(target=capture_screen, args=(self,), daemon=True)
        self.capture_thread.start()

    def stop_capture(self):
        stop_capture()
        self.status_label.setText("Task: Stopped")
        self.append_response("[System] Screen capture stopped")

    # ---------------- Auto toggle ----------------
    def on_toggle_auto(self, state):
        self.auto_mode = (state == Qt.Checked)
        if self.auto_mode:
            self.append_response("⚡ Auto Mode Enabled")
        else:
            self.append_response("✍ Manual Mode Enabled")

    # ---------------- Mic control ----------------
    def toggle_mic(self):
        if self.mic_active:
            self.mic_active = False
            self.mic_btn.setText("🎤 Mic (Off)")
            self.status_label.setText("Mic stopped")
        else:
            self.mic_active = True
            self.mic_btn.setText("🎤 Mic (On)")
            self.status_label.setText("Mic listening...")
            self.mic_thread = threading.Thread(target=self._listen_mic, daemon=True)
            self.mic_thread.start()

    def _listen_mic(self):
        recognizer = sr.Recognizer()
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.8)
                while self.mic_active:
                    try:
                        audio = recognizer.listen(source, timeout=4, phrase_time_limit=6)
                        text = recognizer.recognize_google(audio)
                        print("[Mic] Heard:", text)
                        # append mic text into prompt_input (thread-safe)
                        self.append_prompt_signal.emit(text)
                    except sr.WaitTimeoutError:
                        continue
                    except sr.UnknownValueError:
                        print("[Mic] Could not understand")
                    except Exception as e:
                        print("[Mic] Error:", e)
                        self.response_signal.emit(f"[Mic] Error: {e}")
                        break
        except Exception as e:
            # Microphone could not be opened
            print("⚠️ Microphone error:", e)
            self.response_signal.emit(f"[Mic] Error: {e}")
            self.mic_active = False
            # ensure UI updated
            try:
                self.mic_btn.setText("🎤 Mic (Off)")
            except Exception:
                pass

    # ---------------- Signal handlers ----------------
    def handle_set_prompt(self, prompt_text: str):
        """Called when capture thread emits an auto-prompt suggestion."""
        try:
            self.last_auto_prompt = prompt_text
            # Only set the input if auto_mode is on and the user hasn't typed something
            current = self.prompt_input.text().strip()
            if self.auto_mode and not current:
                self.prompt_input.setText(prompt_text)
        except Exception:
            print("handle_set_prompt error:", traceback.format_exc())

    def handle_append_prompt(self, chunk: str):
        """Append microphone-transcribed chunk to the prompt input (thread-safe)."""
        try:
            current = self.prompt_input.text()
            if current and not current.endswith(" "):
                current += " "
            self.prompt_input.setText(current + chunk)
        except Exception:
            print("handle_append_prompt error:", traceback.format_exc())

    def handle_update_preview(self, pixmap: QPixmap):
        """Set the small preview QPixmap from capture thread."""
        try:
            self.preview_label.setPixmap(pixmap.scaled(
                self.preview_label.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            ))
        except Exception:
            print("handle_update_preview error:", traceback.format_exc())

    def handle_response(self, text: str):
        """Append a response line (model or system) into the response box."""
        self.append_response(text)

    def handle_enable_send(self, enabled: bool):
        """Enable/disable send button (from worker threads)."""
        self.send_btn.setEnabled(enabled)

    # ---------------- Gemini client management ----------------
    def ensure_gemini(self) -> bool:
        """Create Gemini client lazily. Returns True if ready, else False (and logs)."""
        if self.gemini is not None:
            return True
        if not self.api_key:
            self.append_response("[System] GEMINI_API_KEY not set. Please set the environment variable.")
            return False
        try:
            # instantiate gemini client; gemini_client.py must accept api_key and model
            self.gemini = GeminiClient(api_key=self.api_key, model=self.gemini_model)
            # optional: start chat for conversational mode if client supports it
            try:
                self.gemini.start_chat()
            except Exception:
                # not all wrappers need a start_chat step; ignore if not available
                pass
            return True
        except Exception as e:
            self.append_response(f"[System] Gemini client error: {e}")
            print("Gemini init error:", traceback.format_exc())
            self.gemini = None
            return False

    # ---------------- Sending flow ----------------
    def on_send(self):
        """Called when Send button is clicked. Handles Auto vs Manual behavior."""
        # If auto mode and input is empty, ask user to edit auto prompt first:
        text = self.prompt_input.text().strip()
        if self.auto_mode and not text:
            # If we have last_auto_prompt from capture loop, set it and ask user to press Send again.
            if self.last_auto_prompt:
                self.prompt_input.setText(self.last_auto_prompt)
                self.append_response("⚡ Auto-prompt generated. Edit if needed, then press Send again.")
            else:
                self.append_response("[System] Auto-prompt not ready yet. Wait a moment and try again.")
            return

        if not text:
            self.append_response("[System] Please type a prompt or use Auto / mic.")
            return

        # disable send while processing
        self.send_btn.setEnabled(False)
        self.append_response(f"🧑: {text}")

        # perform network call in background
        t = threading.Thread(target=self._send_thread, args=(text,), daemon=True)
        t.start()

    def _send_thread(self, prompt_text: str):
        """Background thread: send prompt (+ last capture image) to Gemini and handle reply."""
        # Ensure client
        if not self.ensure_gemini():
            self.response_signal.emit("[System] Gemini client not available.")
            self.enable_send_signal.emit(True)
            return

        # get last capture path (may be None)
        try:
            image_path = get_last_capture()
        except Exception:
            image_path = None

        try:
            # Use gemini client's send method. Implementation of gemini_client should return text.
            reply = self.gemini.send(prompt_text, image_path=image_path, prefer_chat=True)
            if reply is None:
                reply_text = "[AI] (empty response)"
            else:
                # If gemini returns an object with .text, handle it
                try:
                    reply_text = reply.text if hasattr(reply, "text") else str(reply)
                except Exception:
                    reply_text = str(reply)
            self.response_signal.emit("🤖: " + reply_text)
            # speak if requested
            if self.voice_resp_cb.isChecked():
                threading.Thread(target=self._speak, args=(reply_text,), daemon=True).start()
        except Exception as e:
            self.response_signal.emit("[AI Error] " + str(e))
            print("Send thread exception:", traceback.format_exc())
        finally:
            # re-enable send button
            self.enable_send_signal.emit(True)

    # ---------------- TTS ----------------
    def _speak(self, text: str):
        with self.tts_lock:
            try:
                self.tts_engine.say(text)
                self.tts_engine.runAndWait()
            except Exception as e:
                print("TTS error:", e)
                self.response_signal.emit("[TTS error] " + str(e))

    # ---------------- Helpers ----------------
    def append_response(self, text: str):
        ts = time.strftime("%H:%M:%S")
        try:
            self.response_box.append(f"[{ts}] {text}")
        except Exception:
            # degrade gracefully
            print(f"[{ts}] {text}")

    # ---------------- Quit & Drag support ----------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_pos = event.globalPos() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.LeftButton:
            self.move(event.globalPos() - self.drag_pos)
            event.accept()

    def quit_app(self):
        stop_capture()
        self.mic_active = False
        try:
            self.tts_engine.stop()
        except Exception:
            pass
        QApplication.quit()
        sys.exit(0)


# ---------------- Main ----------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Allow passing GEMINI key by env var; or pass explicitly here: Overlay(gemini_api_key="YOUR_KEY")
    overlay = Overlay()
    overlay.show()
    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        stop_capture()
        sys.exit(0)
