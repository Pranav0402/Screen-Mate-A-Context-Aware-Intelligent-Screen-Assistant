# 🧠 AI Screen Share Assistant  

An intelligent **on-screen assistant** built with **Python, PyQt5, YOLOv8, and EasyOCR** that can analyze your screen, detect UI elements, listen to your voice commands, and assist with contextual understanding using **Gemini API**.

---

## 🚀 Features  
✅ Floating draggable assistant overlay (like a bubble UI).  
✅ Real-time screen capture and OCR (EasyOCR).  
✅ UI element detection using YOLOv8.  
✅ Speech-to-text command recognition (SpeechRecognition + PyAudio).  
✅ Context-aware understanding using Gemini API.  
✅ Automatically logs OCR + voice + window title to context buffer.  

---

## 🗂 Project Structure  

DL_Project/
│
├── captures/ # Saved screenshots
├── path/ # Temporary paths
├── runs/ # YOLOv8 training results
├── ui_dataset/ # Dataset folder (excluded from GitHub)
│
├── context_buffer.jsonl
├── context_buffer.py
├── gemini_client.py
├── ocr_yolo.py
├── overlay.py
├── screen_capture.py
├── task_predictor.py
├── train_yolo.py
├── try.py
├── yolo_detector.py
│
├── requirements.txt
├── .env
├── .gitignore
└── README.md