from ultralytics import YOLO

class YOLODetector:
    def __init__(self, model_path="yolov8s.pt"):
        self.model = YOLO(model_path)

    def detect_labels(self, image_path):
        results = self.model.predict(image_path, verbose=False)
        labels = []
        for r in results:
            labels.extend([self.model.names[int(cls)] for cls in r.boxes.cls])
        return list(set(labels))  # unique labels
