# ocr_yolo.py
import cv2
import torch
import easyocr
from ultralytics import YOLO

# Init OCR + YOLO once
gpu_available = torch.cuda.is_available()
reader = easyocr.Reader(['en'], gpu=gpu_available)
yolo_model = YOLO("ui_best.pt")
print("OCR/YOLO initialized. GPU:", gpu_available)

def analyze_frame(frame_bgr, min_conf=0.3):
    """Return (ocr_data, yolo_data) for a given BGR frame."""
    ocr_data, yolo_data = [], []

    # OCR
    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    for bbox, text, conf in reader.readtext(rgb, detail=1, paragraph=False, min_size=20):
        if conf >= min_conf:
            ocr_data.append({"text": text, "bbox": bbox, "conf": float(conf)})

    # YOLO
    results = yolo_model.predict(frame_bgr, verbose=False)
    for result in results:
        for box in result.boxes:
            cls_id = int(box.cls[0])
            yolo_data.append({
                "class": yolo_model.names[cls_id],
                "conf": float(box.conf[0]),
                "bbox": box.xyxy[0].cpu().numpy().tolist()
            })
    return ocr_data, yolo_data


def generate_auto_prompt(ocr_data, yolo_data):
    """
    Create a natural prompt using OCR text & YOLO UI labels.
    """
    texts = " ".join([d["text"] for d in ocr_data])
    labels = ", ".join(sorted(set(d["class"] for d in yolo_data)))
    if not texts and not labels:
        return "Summarize the current screen and suggest next actions."
    return (
        f"Screen summary request. Text snippets: {texts[:400]}. "
        f"Detected UI elements: {labels or 'none'}. "
        "Provide a concise description and what actions the user might take."
    )
