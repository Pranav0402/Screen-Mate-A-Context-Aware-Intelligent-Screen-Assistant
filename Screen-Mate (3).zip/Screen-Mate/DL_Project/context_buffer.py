import time
import win32gui  # Windows only
import json
import os

CTX_FILE = "context_buffer.jsonl"

class ContextBuffer:
    def __init__(self, max_length=10, save_file=CTX_FILE):
        self.buffer = []
        self.max_length = max_length
        self.save_file = save_file

        # Ensure file exists
        if not os.path.exists(self.save_file):
            open(self.save_file, "w", encoding="utf-8").close()

    def add_context(self, window_title=None, ocr_text=None, speech_text=None):
        # get active window title if not provided
        if window_title is None:
            try:
                window = win32gui.GetForegroundWindow()
                window_title = win32gui.GetWindowText(window)
            except Exception:
                window_title = "Unknown"

        context = {
            "timestamp": time.time(),
            "window_title": window_title,
            "ocr_text": ocr_text,
            "speech_text": speech_text
        }

        # add to in-memory buffer
        self.buffer.append(context)

        # keep only last N
        if len(self.buffer) > self.max_length:
            self.buffer.pop(0)

        # save persistently
        with open(self.save_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(context) + "\n")

    def get_context(self):
        return self.buffer

    def latest(self, n=5):
        """Get last N records from buffer"""
        return self.buffer[-n:]

# 🔥 global instance
ctx = ContextBuffer()
